// 存放在此文件中的数据, 将会在 main.js 中注入到原型中

export let globalData = {
	baseURL: 'http://127.0.0.1:5050/'
}
