import Vue from 'vue'
import App from './App'
import {
	globalData
} from './globalData.js'

// 注入到原型中, 全局使用
Vue.prototype.$global = globalData

Vue.config.productionTip = false

App.mpType = 'app'

const app = new Vue({
	...App
})
app.$mount()
