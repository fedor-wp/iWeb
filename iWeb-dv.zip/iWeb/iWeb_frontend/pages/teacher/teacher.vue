<template>
	<view>
		<view class="header">
			<text>金牌讲师</text>
		</view>
		
		<view class="item" v-for="(item,index) in teachers" :key="index">
			<image :src="$global.baseURL + item.tpic" mode=""></image>
			<view class="content">
				<text class="title">{{item.tname}}&nbsp;&nbsp;&nbsp;&nbsp;{{item.maincourse}}</text>
				<text class="subtitle">工作经历</text>
				<text class="desc">{{item.experience}}</text>
				<text class="subtitle">授课风格</text>
				<text class="desc">{{item.style}}</text>
			</view>
		</view>
		
	</view>
</template>

<script>
	export default {
		data() {
			return {
				teachers:[]
			}
		},
		onLoad() {
			this.getData()
		},
		methods: {
			getData(){
				let url = this.$global.baseURL + 'teacher/list?format=full';
				
				uni.request({
					url:url,
					success: (res) => {
						console.log(res)
						this.teachers = res.data
					},
					fail: (err) => {
						console.log(err)
					}
				})
			}
		}
	}
</script>

<style lang="scss">
.header{
	border-bottom: 1px solid lightgray;
	padding: 10rpx 0;
	
	text{
		color: $theme-color;
		border-bottom: 2px solid $theme-color;
		padding: 0 20rpx 8rpx;
		
		// display: inline-block;
	}
}

.item{
	margin: 25rpx 25rpx;
	display: flex;
	border-bottom: 1px solid lightgray;
	padding-bottom: 25rpx;
	
	image{
		width: 250rpx;
		height:320rpx;
		border-radius: 10rpx;
		margin-right: 25rpx;
	}
	
	.content{
		flex:1;
		display: flex;
		flex-direction: column;
		
		.title{
			color: #ffcc33;
			font-size: 1em;
			margin-bottom: 4rpx;
		}
		
		.subtitle{
			font-size: 0.9em;
			font-weight: bold;
			margin: 10rpx 0;
		}
		
		.desc{
			font-size: .8em;
			color: gray;
			margin-right: 25rpx;
		}
	}
}
</style>
