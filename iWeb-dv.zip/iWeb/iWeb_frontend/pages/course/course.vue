<template>
	<view>
		<!-- 代码提示: use... -->
		<!-- @clickItem 点击事件, 自带参数, 不要写() 结尾 -->
		<uni-segmented-control :current="current" :values="items" styleType="text" active-color="#548aff" @clickItem="clickItem"></uni-segmented-control>
		<view class="content">
			<navigator v-for="(item, index) in list" :key="index" :url="`/pages/courseDetail/courseDetail?cid=${item.cid}`" open-type="navigate">
				<image class="icon" :src="$global.baseURL + item.pic" mode=""></image>
				<view class="detail">
					<text class="title">{{ item.title }}</text>
					<text>讲师: {{ item.tname }}</text>
					<text>课时: {{ item.cLength }}</text>
				</view>
				<image class="right" src="/static/icon/right.png" mode=""></image>
			</navigator>

			<uni-load-more :status="status"></uni-load-more>
		</view>
	</view>
</template>

<script>
export default {
	data() {
		return {
			status: 'more',
			// 在分段选择器上 显示的内容
			items: ['基础课程', '核心课程', '进阶课程'],
			// 当前选项
			current: 0,
			pageCount: 0,
			pageNum: 0,
			pageSize: 0,
			totalCount: 0,
			list: []
		};
	},
	onLoad() {
		this.getData(1, 1);
	},
	// 触底事件
	onReachBottom() {
		console.log('触底事件');
		if (this.pageCount == this.pageNum) return;
		
		this.status = 'loading';
		// 参数3:  mode=2 代表加载更多
		this.getData(this.pageNum+1, this.current+1, 2)
	},
	onPullDownRefresh() {
		// 下拉刷新操作, 需要到 pages.json 中开启才可以
		// 具体开启的配置项: enablePullDownRefresh
		this.getData(1, this.current+1);
	},
	methods: {
		clickItem(e) {
			// console.log(e)
			this.current = e.currentIndex;

			this.getData(1, this.current + 1);
		},
		// 人为设定: mode 1代表刷新,  2代表更多
		getData(pageNum, typeId, mode = 1) {
			let url = this.$global.baseURL + `course/list?pageNum=${pageNum}&typeId=${typeId}`;

			uni.request({
				url: url,
				success: res => {
					console.log(res);
					// 请求完成时, 结束下拉刷新状态
					uni.stopPullDownRefresh();

					if (mode == 2){
						// 更多操作
						res.data.list = this.list.concat(res.data.list);
					}
					this.list = res.data.list;
					
					this.pageCount = res.data.pageCount;
					this.pageNum = res.data.pageNum;
					this.pageSize = res.data.pageSize;
					this.totalCount = res.data.totalCount;
					
					// 判断: 当前页 和 总页数的关系
					if (this.pageNum == this.pageCount){
						this.status = 'noMore';
					}else{
						this.status = 'more';
					}
				},
				fail: err => {
					console.log(err);
				}
			});
		}
	}
};
</script>

<style lang="scss">
navigator {
	display: flex;
	flex-direction: row;
	margin-left: 10rpx;
	padding: 10rpx 10rpx 10rpx 0;
	align-items: center;
	border-bottom: 1px solid lightgray;

	.icon {
		width: 180rpx;
		height: 120rpx;
		min-width: 180rpx;
		margin: 12.5rpx 25rpx;
		border-radius: 7rpx;
	}

	.detail {
		display: flex;
		flex-direction: column;
		font-size: 0.8em;

		.title {
			font-weight: bold;
		}
	}

	.right {
		width: 50rpx;
		height: 40rpx;
		margin-left: auto;
	}

	.price {
		margin-left: auto;
		color: #548aff;
	}
}
</style>
