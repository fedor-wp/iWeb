<template>
	<view class="box">
		<text class="title">{{ data.title }}</text>
		<image class="logo" :src="$global.baseURL + data.pic" mode=""></image>
		<view class="desc">
			<text class="desc-title">讲师 :</text>
			<text class="desc-tname">{{ data.tname }}</text>
		</view>
		<view class="desc">
			<text class="desc-title">课时 :</text>
			<text>{{ data.cLength }}</text>
		</view>
		<view class="desc">
			<text class="desc-title">开课时间 :</text>
			<text>{{ data.startTime }}</text>
		</view>
		<view class="desc">
			<text class="desc-title">上课方式 :</text>
			<text>在线教学</text>
		</view>
		<view class="header"><text class="header-title">课程详情</text></view>
		<text v-html="data.details" class="detail"></text>

		<!-- https://ext.dcloud.net.cn/plugin?id=865 -->
	</view>
</template>

<script>
export default {
	data() {
		return {
			data: {
				options: [
					{
						icon: 'headphones',
						text: '客服'
					},
					{
						icon: 'shop',
						text: '店铺',
						info: 2,
						infoBackgroundColor: '#007aff',
						infoColor: 'red'
					},
					{
						icon: 'cart',
						text: '购物车',
						info: 2
					}
				],
				buttonGroup: [
					{
						text: '加入购物车',
						backgroundColor: '#ff0000',
						color: '#fff'
					},
					{
						text: '立即购买',
						backgroundColor: '#ffa200',
						color: '#fff'
					}
				]
			}
		};
	},
	onLoad(options) {
		console.log(options);
		let cid = options.cid;

		// 发送请求获取数据 并 进行页面的显示
		// 页面最下方的部分, 是uni-ui提供的组件, 可以自行在组件文档中查看并引入使用
		this.getData(cid);
	},
	methods: {
		onClick(e) {
			uni.showToast({
				title: `点击${e.content.text}`,
				icon: 'none'
			});
		},
		buttonClick(e) {
			console.log(e);
			this.options[2].info++;
		},
		getData(cid) {
			let url = this.$global.baseURL + 'course/detail?cid=' + cid;

			uni.request({
				url: url,
				success: res => {
					console.log(res);
					this.data = res.data;
				},
				fail: err => {
					console.log(err);
				}
			});
		}
	}
};
</script>

<style lang="scss">
.title {
	text-align: center;
	width: 100%;
	display: inline-block;
	// background-color: red;
	font-size: 1em;
	padding: 10rpx 0;
}

.logo {
	height: 470rpx;
	width: 750rpx;
}

.desc {
	margin: 12.5rpx 25rpx;
}

.desc-title {
	font-weight: bold;
	margin-right: 25rpx;
}

.desc-tname {
	color: $theme-color;
}

.desc-navi {
	display: inline;
	color: $theme-color;
}

.header {
	padding-bottom: 3px;
	border-bottom: 1px solid lightgray;
	margin: 12.5rpx 25rpx;
}

.header-title {
	font-weight: bold;
	padding: 2px;
	border-bottom: 2px solid $theme-color;
}

.detail {
	font-size: 0.8em;
	padding: 12.5rpx 25rpx;
	display: inline-block;
}

.cart{
	position: fixed;
	bottom: 0;
	left: 0;
	right: 0;
}

.box{
	padding-bottom: 25px;
}
</style>
