<template>
	<view>
		<!-- 滑块组件: swiper -->
		<swiper :indicator-dots="true" :autoplay="true" :interval="3000" :duration="250" :circular="true">
			<swiper-item v-for="(item, index) in banners" :key="index"><image :src="'../../static/images/' + item" mode=""></image></swiper-item>
		</swiper>

		<!-- 最新课程 -->
		<view class="header">
			<text>最新课程</text>
			<!-- url: 内容与pages.json 中的页面地址一样 -->
			<navigator url="/pages/course/course" open-type="switchTab">更多</navigator>
	
		</view>

		<view class="list">
			<navigator v-for="(item, index) in courseNew" :key="index" :url="`/pages/courseDetail/courseDetail?cid=${item.cid}`" open-type="navigate">
				<view class="item">
					<!-- $global 在main.js 中注入的 -->
					<image :src="$global.baseURL + item.pic" mode=""></image>
					<text>{{ item.title }}</text>
				</view>
			</navigator>
		</view>
		
		<!-- 名师堂 -->
		<view class="header">
			<text>名师堂</text>
			<!-- url: 内容与pages.json 中的页面地址一样 -->
			<navigator url="/pages/teacher/teacher" open-type="switchTab">更多</navigator>
		</view>
		
		<scroll-view scroll-x="true" class="teacher-list" >
			<view class="teacher" v-for="(item,index) in teachers" :key="index">
				<image :src="$global.baseURL + item.tpic" mode=""></image>
				<text class="tname">讲师: {{item.tname}}</text>
				<text class="maincourse">{{item.maincourse}}</text>
			</view>
		</scroll-view>
	</view>
</template>

<script>
export default {
	data() {
		return {
			banners: ['banner01.jpg', 'banner02.jpg'],
			courseNew: [],
			courseHot: [],
			teachers:[]
		};
	},
	onLoad() {
		this.getNew();
		this.getHot();
		this.getTeachers();
	},
	methods: {
		getTeachers(){
			let url = this.$global.baseURL + 'teacher/list?format=short';
			
			uni.request({
				url:url,
				success: (res) => {
					console.log(res)
					this.teachers = res.data
				},
				fail: (err) => {
					console.log(err)
				}
			})
		},
		
		getHot() {
			let url = this.$global.baseURL + 'course/hottest?count=4';

			uni.request({
				url: url,
				success: res => {
					console.log(res)
					this.courseHot = res.data
				},
				fail: err => {
					console.log(err)
				}
			});
		},

		getNew() {
			// 获取最新课程
			let baseurl = 'http://localhost:5050/';
			let url = baseurl + 'course/newest?count=4';

			uni.request({
				url: url,
				success: res => {
					console.log(res);
					this.courseNew = res.data;
				},
				fail: err => {
					console.log(err);
				}
			});
		}
	}
};
</script>

<!-- lang="scss" 代表此css写法 需要用scss 来编译 -->
<style lang="scss">
// 单位 rpx:  屏幕宽固定 750rpx
$swiper-height: 300rpx;

swiper {
	height: $swiper-height;

	image {
		width: 100%;
		height: $swiper-height;
	}
}

.header {
	display: flex;
	border-bottom: 1px solid #c0c0c0;
	padding: 25rpx 25rpx 0 25rpx;
	justify-content: space-between;

	// scss的语法:  可以在选择器里 继续写子选择器
	text {
		font-weight: bold;
		font-size: 1em;
		color: $theme-color;
		border-bottom: 3rpx solid $theme-color;
		padding-bottom: 10rpx;
	}

	navigator {
		font-size: 0.8em;
		color: $uni-color-subtitle;
		display:flex;
		align-items: center;
	}
}

.list {
	display: flex;
	flex-direction: row;
	flex-wrap: wrap; //允许子元素换行
	justify-content: space-evenly;
	margin-bottom: 30rpx;
	padding: 0rpx 12.5rpx;

	.item {
		width: 320rpx;
		font-size: 0.75em;
		text-align: center;
		// background-color: rgba(0, 0, 0, 0.1);
		padding: 30rpx 12.5rpx 0 12.5rpx;
		border-radius: 10rpx;

		image {
			width: 100%;
			height: 201rpx;
			border-radius: 10rpx;
		}

		.tname-price {
			// width: 100%;
			display: flex;
			justify-content: space-between;
			//padding: 0 20rpx;

			.tname {
				color: rgb(110, 110, 110);
			}

			.price {
				color: #548aff;
			}
		}

		> text {
			font-size: 1.1em;
		}
	}
}

.teacher-list{
	white-space: nowrap;
	margin-bottom: 30rpx;
	
	.teacher{
		display: inline-block;
		flex-direction: column;
		width: 210rpx;
		margin: 20rpx;
		
		.tname{
			font-size: 0.75em;
		}
		
		.maincourse{
			font-size: 0.65em;
			color: gray;
		}
	}
	
	image{
		width: 100%;
		height:265rpx;
		border-radius: 10rpx;
	}
	
	text{
		display: block;
		text-align: center;
	}
	

}
</style>
