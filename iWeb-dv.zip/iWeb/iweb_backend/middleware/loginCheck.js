/**
 * 登录检查中间件
 */
module.exports = (req, res, next)=>{
	if( !req.session.userInfo ){ 	//首先验证用户是否登录了
		let output = {
			code: 409,
			msg: 'login required'
		}
		res.send(output)
		return 
	}
	next()   //放行，继续执行后续的路由/中间件
}