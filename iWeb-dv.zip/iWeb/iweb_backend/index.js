/**
 * iWeb项目后台API子系统的入口模块
 */
const express = require('express')

//①启动服务器
let port = 5050		//如果使用了新浪云，此处只能使用5050端口
let app = express()
app.listen(port, ()=>{
	console.log('Server Listening on PORT: ', port)
})

//②添加前置中间件
app.use(express.static('public/'))  //对public目录下的静态文件进行托管

const bodyParser = require('body-parser')
app.use(bodyParser.json())//解析请求消息中的JSON主体数据，保存到req.body属性中

const session = require('express-session')
app.use(session({  //为客户端分配sessionId,并为每个sessionId在服务器端分配存储空间
	secret: 'tedu123456', //秘钥,口令,用于生成随机的sessionId的种子
	saveUninitialized: true,  //自动保存未经手工初始化的session吗?
	resave: true,  //是否自动保存,无需手工调用 req.session.save()来保存数据了
}))

const cors = require('cors')
app.use(cors( ))//跨域CORS解决方案: 服务器在相应消息中明确指定允许当前客户端使用响应消息
//TODO: 此次没有考虑跨域session问题!



//③执行业务逻辑——接收请求返回响应——由路由和路由器完成
const userRouter = require('./router/user.js')			//处理所有以'/user'开头请求的路由器
app.use('/user', userRouter)
const favoriteRouter = require('./router/favorite.js')	//处理所有以'/favorite'开头请求的路由器
const loginCheck = require('./middleware/loginCheck.js')
app.use('/favorite', loginCheck)	//所有收藏夹相关路由都需要登录检查
app.use('/favorite', favoriteRouter)
const typeRouter = require('./router/type.js')			//处理所有以'/type'开头请求的路由器
app.use('/type', typeRouter)
const courseRouter = require('./router/course.js')		//处理所有以'/course'开头请求的路由器
app.use('/course', courseRouter)
const cartRouter = require('./router/cart.js')			//处理所有以'/cart'开头请求的路由器
app.use('/cart', loginCheck)		//所有购物车相关路由都需要登录检查
app.use('/cart', cartRouter)
const teacherRouter = require('./router/teacher.js')	//处理所有以'/teacher'开头请求的路由器
app.use('/teacher', teacherRouter)


//④添加后置中间件
//Express默认提供了一个错误处理中间件，形如：app.use((err, req, res, next)=>{})
//此处可以自定义一个错误处理中间件，覆盖Express提供的默认错误处理中间件
app.use((err, req, res, next)=>{	//错误处理中间件第一次参数是err
	//console.log(err)   //不推荐：一般的云服务器不提供控制台展示
	//fs.writeFile('err.log', err)	//推荐：把错误消息输出到一个日志文件中
	res.status(500)
	let output = {
		code: 500,
		msg: "服务器运行出错！请稍后重试！",
		err: err
	}
	res.send(output)
})