/**
 * iWeb项目后台API子系统必需的数据库连接池模块
 */
const mysql = require('mysql')

let pool = mysql.createPool({
	host:					'127.0.0.1',			//数据库服务器的域名或IP地址
	port:					'3306',					//端口号
	user:					'root',					//连接数据库服务器所需管理员用户名
	password:				'',						//管理员密码
	database:				'iweb',					//项目数据库名
	connectionLimit:		10						//连接池最大容量
})

module.exports = pool		//导出连接池模块，供其它模块使用
/*
pool.query('SELECT  1+2',  (err, result)=>{
	if(err)throw err		//注意：在真正的上线项目中，决不允许throw err！
	console.log(result)
})
*/