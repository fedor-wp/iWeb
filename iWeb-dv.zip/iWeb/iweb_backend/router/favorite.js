/**
 * 处理所有以/favorite开头的请求
 */
const express = require('express')
const pool = require('../pool')
let router = express.Router()
module.exports = router		//此处先执行模块的导出，再向其中添加路由处理

/**
 * 1.7	添加收藏
 * 接口URL
 *	{{url}}/favorite/add
 * 请求方式
 *	POST
 * 请求 Content-Type
 *	application/json
 * 请求Body参数
 *	uid	3	必需	-用户id 从服务器端session中读取登录的用户编号
 *	cid	7	必填	-课程id
 * 成功响应示例
 *	{
		"code": 200,
		"msg": "success",
		"fid": 2
 *	}
 * 失败响应示例
 *	{
		"code": 403,
		"msg": "failed"
 * 	}
 */
router.post('/add', (req, res, next)=>{
	//1.读取请求数据
	/*if( !req.session.userInfo ){ 	//验证用户是否登录了: 已被中间件代替
		let output = {
			code: 409,
			msg: 'login required'
		}
		res.send(output)
		return 
	}*/
	let uid = req.session.userInfo.uid		//从会话中获得登录后得到的用户编号
	
	let cid = req.body.cid					//从请求主体中获取课程编号
	if(!cid){
		let output = {
			code: 403,
			msg: 'cid required'
		}
		res.send(output)
		return 
	}
	
	let time = Date.now()					//收藏时间
	
	//2.执行数据库操作
	//TODO: sql1: 查询当前用户编号是否收藏过当前课程
	//TODO: sql2: 如果未添加该收藏,执行INSERT
	//TODO: sql3: 如果之前添加该收藏,执行UPDATE,把fTime修改为最新时间
	let sql = "INSERT INTO  favorite VALUES(NULL, ?, ?, ?)"
	pool.query(sql,[uid, cid, time], (err, result)=>{
		if(err){
			next(err)
			return
		}
		//3.输出响应消息
		let output = {
			code: 200,
			msg: 'favorite added success',
			fid: result.insertId,			//新记录在数据库中的自增编号
		}
		res.send(output)
	})
	
})


/**
 * 1.8	收藏列表
 * 接口URL
 * 	{{url}}/favorite/list
 * 请求方式
 *	GET
 * 请求参数
 *	uid	4	必需	-用户id从session中读取登录的用户编号即可
 * 成功响应示例
 *	[
        {
            "title": "07HTML零基础入门",
            "pic": "img-course\/06.png",
            "price": 399,
            "courseId": 7,
            "fid": 2,
            "fTime": 1578015036
        },
       ....
 * 	]
 */
router.get('/list', (req, res, next)=>{
	//1.读取请求数据
	let uid = req.session.userInfo.uid
	
	//2.执行数据库查询
	let sql = 'SELECT title,pic,price,courseId,fid,fTime  FROM  course AS c,  favorite AS f  WHERE c.cid=f.courseId  AND  userId=?  ORDER  BY  fTime  DESC'
	pool.query(sql, uid, (err, result)=>{
		if(err){
			next(err)
			return
		}
		//3.输出响应消息
		res.send(result)
	})
})