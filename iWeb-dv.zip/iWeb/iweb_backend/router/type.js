/**
 * 处理所有以/type开头的请求
 */
const express = require('express')
const pool = require('../pool')
let router = express.Router()
module.exports = router		//此处先执行模块的导出，再向其中添加路由处理

/**
 * 
 */


