/**
 * 处理所有以/course开头的请求
 */
const express = require("express");
const pool = require("../pool");
let router = express.Router();
module.exports = router; //此处先执行模块的导出，再向其中添加路由处理

/**
 * 2.2	获取课程列表
 * 接口URL
 *	{{url}}/course/list?pageNum=1&typeId=3
 * 请求方式
 *	GET
 * 请求查询字符串参数
 *		pageNum	1	可选	-当前页码
 *		typeId	3	可选	-课程分类id
 * 成功响应示例
 *	{
		"pageNum": 1,
		"pageSize": 5,
		"pageCount": 3,
		"totalCount": 11,
		"list": [
			{
				"cid": 12,
				"typeId": 3,
				"title": "12HTML零基础入门",
				"teacherId": 4,
				"cLength": "1天",
				"startTime": "每周一开课",
				"address": "i前端各校区 ",
				"pic": "img-course\/01.png",
				"price": 399,
				"tpid": 3,
				"tpname": "进阶课程",
				"tid": 4,
				"tname": "纪盈鑫",
				"maincourse": "JS框架专家",
				"tpic": "img-teacher\/zzl.jpg"
			},
			.....
		]
 *	}
 */
router.get("/list", (req, res, next) => {
  //1.读取请求数据
  let pageNum = req.query.pageNum;
  if (!pageNum) {
    //客户端未提交页号
    pageNum = 1;
  } else {
    //客户端通过查询字符串提交了页号，解析为整数
    pageNum = parseInt(pageNum);
  }

  let typeId = req.query.typeId;
  let where = ""; //SQL中的where查询条件
  let placeholders = []; //?占位符对应的参数值
  if (typeId) {
    where += " AND  typeId=? ";
    placeholders.push(typeId);
  }
  let output = {
    pageNum: pageNum, //要显示的页号
    pageSize: 8, //页面大小——每页最多显示的记录数
    pageCount: 0, //总页数
    totalCount: 0, //满足条件的总记录数
    list: [], //满足条件的页号上的记录
  };
  //2.执行数据库查询
  //sql1：计算满足条件的记录数量
  let sql1 = "SELECT  COUNT(*) AS c  FROM  course  WHERE  1 " + where;
  pool.query(sql1, placeholders, (err, result) => {
    if (err) {
      next(err);
      return;
    }
    output.totalCount = result[0].c; //总记录数
    output.pageCount = Math.ceil(output.totalCount / output.pageSize); //总页数

    //sql2：获取指定页号上的记录内容
    let sql2 =
      "SELECT  cid,typeId,title,teacherId,cLength,startTime,address,pic,price,tpid,tpname,tid,tname,maincourse,tpic  FROM  type, course, teacher  WHERE course.typeId=type.tpid  AND  course.teacherId=teacher.tid " +
      where +
      " ORDER BY cid LIMIT ?,?";
    placeholders.push((output.pageNum - 1) * output.pageSize); //LIMIT后的第一个?的值：从哪条记录开始读取
    placeholders.push(output.pageSize); //LIMIT后第二个?的值：页面大小
    pool.query(sql2, placeholders, (err, result) => {
      if (err) {
        next(err);
        return;
      }
      output.list = result;
      res.send(output);
    });
  });
  //第1页：  LIMIT  0,5
  //第2页：  LIMIT  5,5
  //第3页：  LIMIT  10,5
  //第N页：  LIMIT  (N-1)*5,5
});

/**
 * 2.4	获取最新课程
 * 接口URL
 *	{{url}}/course/newest?count=4
 * 请求方式
 *	GET
 * 请求Query参数
 *		count	4	可选	-返回结果数量，默认为4
 * 成功响应示例
 *	[
		{
			"cid": 12,
			"title": "12HTML零基础入门",
			"pic": "img-course/01.png",
			"price": 399,
			"tname": "纪盈鑫"
		}，
		.......
 *	]
 */
router.get("/newest", (req, res, next) => {
  let count = req.query.count; //客户端想请求前几个
  if (!count) {
    count = 4;
  } else {
    count = parseInt(count);
  }

  let sql =
    "SELECT cid,title,pic,price,tname  FROM  course, teacher  WHERE course.teacherId=teacher.tid  ORDER BY  cid  DESC   LIMIT  ?"; //LIMIT ? 表示取前几条记录
  pool.query(sql, count, (err, result) => {
    if (err) {
      next(err);
      return;
    }
    res.send(result);
  });
});

/**
 * 2.5	获取热门课程
 * 接口URL
 *	{{url}}/course/hottest?count=4
 * 请求方式
 *	GET
 * 请求查询字符串参数
 *	count	4	可选	-返回结果数量，默认值为4
 * 成功响应示例
 *	[
		{
			"cid": 12,
			"title": "12HTML零基础入门",
			"pic": "img-course/01.png",
			"price": 399,
			"tname": "纪盈鑫"
		},
		......
 *	]
 */
router.get("/hottest", (req, res, next) => {
  let count = req.query.count; //客户端想请求前几个
  if (!count) {
    count = 4;
  } else {
    count = parseInt(count);
  }

  let sql =
    "SELECT cid,title,pic,price,tname,buyCount  FROM  course, teacher  WHERE course.teacherId=teacher.tid  ORDER BY  buyCount  DESC   LIMIT  ?"; //LIMIT ? 表示取前几条记录
  pool.query(sql, count, (err, result) => {
    if (err) {
      next(err);
      return;
    }
    res.send(result);
  });
});

/**
 * 详情接口
 */
router.get("/detail", (req, res, next) => {
  let cid = req.query.cid;
  if (!cid) {
    res.send("cid required!");
    return;
  }

  sql =
    "SELECT * FROM course,teacher WHERE course.cid=? AND teacher.tid=course.teacherId";
  pool.query(sql, cid, (err, result) => {
    if (err) {
      next(err);
      return;
    }
    res.send(result[0]);
  });
});
