/**
 * 处理所有以/user开头的请求
 */
const express = require('express')
const multer = require('multer')
const fs = require('fs')	//Node.js官方模块，用于文件操作
const pool = require('../pool')
let router = express.Router()
module.exports = router //此处先执行模块的导出，再向其中添加路由处理


/**
 * 1.1	用户注册
 * 接口URL
 *	{{url}}/user/register
 * 请求方式
 *	POST
 * 请求 Content-Type				
 *	application/json
 * 请求Body参数
 *	uname	zhangsan	必填	-用户名
 *	upwd	123456	必填	-密码
 *	phone	13333333333	必填	-手机号
 *	captcha	ad31	必填	-验证码
 * 成功响应示例
 *	{
 *		"code": 200,
 *		"msg": "register success",
 *		"uid": 7
 *	}
 */
router.post('/register', (req, res, next)=>{
	//1.接收客户端提交的请求数据
	//console.log(req.body)	//默认情况下，req没有body属性的；使用前置中间件添加此属性
	let uname = req.body.uname
	if(!uname){
		let output = {
			code: 401,
			msg: 'uname required'
		}
		res.send(output)
		return 
	}
	let upwd = req.body.upwd
	if(!upwd){
		let output = {
			code: 402,
			msg: 'upwd required'
		}
		res.send(output)
		return 
	}
	let phone = req.body.phone
	if(!phone){
		let output = {
			code: 403,
			msg: 'phone required'
		}
		res.send(output)
		return 
	}
	//2.执行数据库操作
	//TODO：插入数据前应该先检查uname和phone是否已被占用：
	//let sql = 'SELECT uid FROM user WHERE uname=? OR phone=?'
	let sql = 'INSERT INTO user(uname, upwd, phone) VALUES(?,?,?)'
	pool.query(sql, [uname,upwd,phone], (err, result)=>{
		if(err){
			next(err)
			return
		}
		//3.输出响应消息
		let output = {
			code: 200,
			msg: 'register success',
			uid: result.insertId	//将INSERT生成的自增编号返回给客户端
		}
		res.send(output)
	})
})


/**
 * 1.2	用户登录
 * 接口URL
 *	{{url}}/user/login
 * 请求方式
 *	POST
 * 请求 Content-Type
 *	application/json
 * 请求Body参数
 *	uname	lisi	必填	-用户名
 *	upwd	abc123	必填	-密码
 * 成功响应示例
 *	{
 *		"code": 200,
 *		"msg": "login success",
 *		"userInfo": {
 *			"uid": 5,
 *			"uname": "ranran@tedu.cn",
 *			"nickname": "然然"    
 *		}
 *	}
 */
router.post('/login', (req, res, next)=>{
	//1.读取请求数据
	let uname = req.body.uname
	if(!uname){
		let output = {
			code: 401,
			msg: 'uname required'
		}
		res.send(output)
		return
	}
	let upwd = req.body.upwd
	if(!upwd){
		let output = {
			code: 402,
			msg: 'upwd required'
		}
		res.send(output)
		return
	}
	//2.执行数据库操作
	let sql = "SELECT uid,uname,nickname FROM user WHERE uname=? AND upwd=?"
	pool.query(sql, [uname, upwd], (err, result)=>{
		if(err){
			next(err)
			return
		}
		//3.输出与响应消息
		if(result.length===0){	//根据uname和upwd没有查询到数据
			let output = {
				code: 400,
				msg: 'uname or upwd err'
			}
			res.send(output)
		}else {					//查询到数据,登录成功
			//HTTP是无状态的协议,此处使用session技术存储客户端访问数据
			//每个客户端在服务器存储的数据都要根据客户端请求出示的id来查找
			req.session.userInfo = result[0]	
			//在当前客户端对应的服务器端存储空间中保存自己专有的数据
			//console.log('req.session: ',  req.session)
			let output = {
				code: 200,
				msg: 'login success',
				userInfo: result[0]
			}
			res.send(output)
		}
	})
})



/**
 * 1.3	检测用户名是否存在
 * 接口URL
 * 		{{url}}/user/check_uname?uname=zhangsan
 * 请求方式
 *		GET
 * 请求查询字符串参数
 *		uname	zhangsan	必填	-用户名
 * 成功响应示例
 * 	{
 *		"code": 200,
 *		"msg": "exists"
 *	}
 * 失败响应示例
 *	{
 *		"code": 401,
 *   	"msg": "non-exists"
 * 	}
 */
router.get('/check_uname', (req, res, next) => {
	//接收客户端提交的请求数据
	let uname = req.query.uname
	if (!uname) {
		let output = {
			code: 400,
			msg: 'uname required'
		}
		res.send(output)
		return
	}
	//执行数据库操作
	let sql = 'SELECT  uid  FROM  user  WHERE   uname=?'
	pool.query(sql, uname, (err, result) => {
		/*
		if(err)throw err			//商业项目中，不允许这样使用
		*/
		/*
		try{
			if(err)throw err		//不会导致服务器奔溃，但是太啰嗦
		}catch(err){
			console.log(err)
		}
		*/
		if (err) {
			next(err) 	//将错误转交给中间件链中的下一个错误处理中间件
			return		//退出当前的路由处理，只跳转到错误处理中间件
		}


		if (result.length === 0) { //根据指定的uname，没有查询到数据
			let output = {
				code: 401,
				msg: 'non-exists'
			}
			res.send(output)
		} else { //根据指定的uname，查询到了相关数据
			let output = {
				code: 200,
				msg: 'exists'
			}
			//向客户端输出响应消息
			res.send(output)
		}
	})
})



/**
 * 1.4	检测手机号是否存在
 * 接口URL
 *	{{url}}/user/check_phone
 * 请求方式
 * 	GET
 * 请求查询字符串参数
 *	phone	13333333333	必填	-手机号
 * 成功响应示例
 *	{
 *		"code": 200,
 *		"msg": "exists"
 *	}
 * 失败响应示例
 *	{
 *   	"code": 402,
 *   	"msg": "non-exists"
 *	}
 */
router.get('/check_phone', (req, res, next) => {
	//接收客户端提交的请求数据
	let phone = req.query.phone
	if (!phone) {
		let output = {
			code: 400,
			msg: 'phone required'
		}
		res.send(output)
		return
	}
	//执行数据库操作
	let sql = 'SELECT  uid  FROM  user  WHERE   phone=?'
	pool.query(sql, phone, (err, result) => {
		if (err) {
			next(err) 	//将错误转交给中间件链中的下一个错误处理中间件
			return		//退出当前的路由处理，只跳转到错误处理中间件
		}

		if (result.length === 0) { 	//根据指定的phone，没有查询到数据
			let output = {
				code: 402,
				msg: 'non-exists'
			}
			res.send(output)
		} else { 					//根据指定的phone，查询到了相关数据
			let output = {
				code: 200,
				msg: 'exists'
			}
			res.send(output)
		}
	})
})



/**
 * 1.5	注册用验证码
 * 接口URL
 * 	{{url}}/user/register/captcha
 * 请求方式
 *	GET
 * 请求参数
 *	无
 * 成功响应示例
 *	SVG图片：<svg>...</svg>
 * 	同时在服务器端session中保存 captcha.register 字段，值为显示给客户端的随机验证码内容。
 */
router.get('/register/captcha', (req, res, next)=>{
	const  svgCaptcha = require('svg-captcha')
	//创建验证码
	//let captcha = svgCaptcha.create( )//使用默认选项创建验证码 {text:'ab12',data:'<svg>...</svg>'}
	let captcha = svgCaptcha.create({
		size: 5,	//验证码长度
		ignoreChars: '0oO1lI2Z', //排除的字符
		noise: 4,	//干扰线数量
		color: true,	//字符是否有颜色
		background: '#c1eebd',	//背景颜色
		width: 130,
		height: 30,
		fontSize: 45,
		//charPreset: 'a-zA-Z0-9', //预设字符
	})	
	
	//console.log(captcha.text)	//此次随机生成的验证码文字，保存在服务器端等待后续验证
	req.session.captcha = {	
		//register: captcha.text
		register: captcha.text.toLowerCase()	//保存纯小写形式的验证码内容
	}
	//console.log(captcha.data) //此次生成的svg图片
	res.type('svg').send(captcha.data)
})


/**
 * 1.6	上传用户头像
 * 接口URL
 *	{{url}}/user/upload/avatar
 * 请求方式
 *	POST
 * 请求 Content-Type
 *	multipart/form-data
 * 请求主体数据
 *	avatar		必填	-二进制图片文件数据
 * 成功响应示例
 *	{
		"code": 200,
		"msg": "upload succ",
		"fileName": "/images/avatar/158632317406812345.jpg"
 * 	}
 */
//使用multer中间件接收客户端上传的一张头像图片
let upload = multer({
	dest: 'temp/',	//客户端上传的图片在服务器上的临时存储路径
})
router.post('/upload/avatar', upload.single('avatar'), (req, res, next)=>{
	//console.log('req.body: ', req.body)	//body中存储着客户端提交的字符字段
	//console.log('req.file: ', req.file) //file中存储着客户端提交的文件字段
	//根据原文件生成新文件名
	let newFileName = generateFileName( req.file.originalname ) 
	//把客户端上传的图片文件从临时目录，保存到静态资源托管目录
	fs.rename(req.file.path,  'public/'+newFileName, (err)=>{
		if(err){
			next(err)
			return
		}
		let output = {
			code: 200,
			msg: 'avatar upload success',
			fileName: newFileName		//向客户端输出生成的文件名
		}
		res.send(output)
	})
})

function generateFileName( originalName ){
	//生成新的随机文件名： images/avatar/ + 时间戳 + 五位随机数 + 原始后缀名
	let  file = 'images/avatar/'
	file += Date.now()
	file += Math.floor( Math.random()*90000+10000 )
	file += originalName.substring( originalName.lastIndexOf('.') ) //从最后一个.处求子串
	return  file
}
